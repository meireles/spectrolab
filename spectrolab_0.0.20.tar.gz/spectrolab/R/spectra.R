################################################################################
# Internal constructor helper for each spectra component
################################################################################

#' Internal constructor for value matrix
#'
#' \code{i_value} constructs value matrix in the appropriate format
#'
#' Coerces input form different formats into data conformable to value,
#' which is a numeric matrix with no dimension names.
#'
#' @param x numeric matrix, dataframe or vector (in case of single spectrum)
#' @param nbands Integer of expected number of bands.
#'                     If NULL (default) checking is skipped.
#' @param nsample Integer of expected number of samples.
#'                If NULL (default) checking is skipped.
#' @return data conformable to relative value: numeric matrix
#'
#' @keywords internal
#' @author Jose Eduardo Meireles
i_value = function(x, nbands = NULL, nsample = NULL) {

    ## test if x dimensions conform to nbands and nsample
    if(is.vector(x)) {
        x = t(matrix(as.numeric(as.character(x))))
    }

    if(is.data.frame(x)) {
        ## Assumes that `as.matrix` converts factors to character
        x = as.matrix(x)
    }

    ## test if x dimensions conform to nbands and nsample
    if( !is.null(nbands) && nbands != ncol(x) ){
        stop("Number of columns in x must be equal nbands")
    }

    if( !is.null(nsample) && nsample != nrow(x) ){
        stop("Number of rows in x must be equal nsample")
    }

    ## Clean up matrix dimension names
    dimnames(x) = NULL

    ## Ensure that x is numeric
    mode(x) = "numeric"

    x
}


#' Internal constructor for sample names
#'
#' \code{i_names} constructs a sample name vector in the appropriate format
#'
#' @param x vector of labels. Should be character.
#' @param nsample Integer of expected number of samples.
#'                If NULL (default) checking is skipped.
#' @return vector of sample names coerced to character
#'
#' @keywords internal
#' @author Jose Eduardo Meireles
i_names = function(x, nsample = NULL){

    if( ! is.null(dim(x)) ){
        stop("Sample names must be one dimensional")
    }

    x = as.character(unlist(x))

    if( !is.null(nsample) && nsample != length(x) ){
        stop("The length of x must be the same as nsample")
    }

    x
}


#' Internal band constructor for spectra
#'
#' \code{i_bands} coerces band labels to a numeric vector.
#'
#' Band labels are \strong{not} required to be unique. Duplicate wavelengths ---
#' for example where two detectors of a full-range spectrometer overlap in a raw,
#' un-spliced spectrum --- are preserved exactly as given, just like duplicate
#' sample names. Label-based band selection (\code{x[, 600]}) returns every
#' matching band, and the internal splice functions select columns positionally
#' so duplicates never corrupt them.
#'
#' (Earlier versions nudged duplicate wavelengths by a tiny amount to force
#' uniqueness. That silently altered the data --- a physical wavelength like 600
#' became 600.0012 --- was buggy for three or more identical values, and is no
#' longer done. See ai_reviews/DUPLICATE_BANDS_ANALYSIS.md.)
#'
#' @param x vector of bands. Either numeric or character
#' @param nbands Integer of expected number of bands.
#'                     If NULL (default) checking is skipped.
#' @return numeric vector of bands, with any duplicates preserved
#'
#' @keywords internal
#' @author Jose Eduardo Meireles
i_bands = function(x, nbands = NULL) {
    if(! is.vector(x)) {
        stop("bands names must be in a vector")
    }

    if( !is.null(nbands) && nbands != length(x) ){
        stop("The length of x must be the same as nbands")
    }

    y = suppressWarnings(as.numeric(x))
    n = is.na(y)
    if( any(n) ){
        stop("band cannot be converted to numeric: ", x[n])
    }

    y
}

#' Internal metadata constructor for spectra
#'
#' \code{i_meta} constructs a metadata data.frame in the appropriate format
#'
#' @param x data.frame
#' @param nsample number of samples in spectra
#' @param allow_null boolean. If TRUE (default) and x is NULL, the function will
#'                   return NULL regardless of nsample
#' @param match_nsample extend or trim the metadata to match the number of samples?
#' @return data.frame
#'
#' @keywords internal
#' @author Jose Eduardo Meireles
i_meta = function(x, nsample, allow_null = TRUE, match_nsample = FALSE){

    if(is.null(x) && allow_null){
        m = matrix(NA, nrow = nsample, ncol = 0)
        return(as.data.frame(m))
    }

    if( is.matrix(x) ){
        x = data.frame(x)
    }

    if( ! is.data.frame(x) ){
        stop("x must be a data.frame")
    }

    if(nsample != nrow(x)){
        if(match_nsample){
            x = x[ rep(seq_len(nrow(x)), length.out = nsample), , drop = FALSE ]
        } else {
            stop("The number of rows of meta must be the same as nsample")
        }
    }

    if(ncol(x) > 0 && is.null(colnames(x))){
        stop("metadata elements (columns) must be named")
    }

    rownames(x) = NULL

    x
}


########################################
# Constructor interface
########################################

#' Assemble a spectra object from already-validated components
#'
#' \code{new_spectra} is the low-level constructor: it assembles the four
#' components into a \code{spectra} object WITHOUT coercion or validation.
#' Callers are responsible for passing correctly-typed components: a numeric
#' matrix \code{value} (N samples x M bands, no dimnames), a numeric
#' \code{bands} vector of length M, a character \code{names} vector of length N,
#' and a \code{data.frame} \code{meta} with N rows. The public, validating,
#' user-facing constructor is \code{\link{spectra}}, which coerces its inputs
#' via the \code{i_*} helpers and then delegates here.
#'
#' Splitting a fast internal assembler from the validating public constructor is
#' a common pattern in modern R packages (e.g. vctrs) and gives internal code a
#' cheap, allocation-light way to rebuild spectra while keeping user-facing
#' construction safe.
#'
#' @param value numeric matrix, N samples by M bands, no dimnames
#' @param bands numeric vector of length M
#' @param names character vector of length N
#' @param meta data.frame with N rows (0 or more columns)
#' @return spectra object
#'
#' @keywords internal
#' @author Jose Eduardo Meireles
new_spectra = function(value, bands, names, meta){
    structure(list(value = value,
                   bands = bands,
                   names = names,
                   meta  = meta),
              class = "spectra")
}


#' Spectra object constructor
#'
#' \code{spectra} "manually" creates a spectra object
#'
#' @param value N by M numeric matrix. N samples in rows and M bands
#'                    in columns
#' @param bands band names in vector of length M
#' @param names sample names in vector of length N
#' @param meta spectra metadata. defaults to NULL. Should be either of length or
#'             nrow equals to the number of samples (nrow(value) or length(names))
#' @param extend_meta defaults to FALSE. If TRUE, then the nrow of meta can be
#'             different from the number of samples and the constructor repeats
#'             the metadata times to match the sample length
#' @return spectra object
#'
#' @note This function resorts to an ugly hack to deal with metadata assignment.
#'       Need to think a little harder to find a solution.
#' @author Jose Eduardo Meireles
#' @export
#'
#' @examples
#' library(spectrolab)
#' # 1. Create a value matrix.
#' #    In this case, by removing the first column that holds the species name
#' rf = spec_matrix_example[ , -1]
#'
#' # (2) Create a vector with band labels that match
#' #     the value matrix columns.
#' wl = colnames(rf)
#'
#' # (3) Create a vector with sample labels that match
#' #     the value matrix rows.
#' #     In this case, use the first colum of spec_matrix_example
#' sn = spec_matrix_example[ , 1]
#'
#' # Finally, construct the spectra object using the `spectra` constructor
#' spec = spectra(value = rf, bands = wl, names = sn)
spectra = function(value,
                   bands,
                   names,
                   meta        = NULL,
                   extend_meta = FALSE){

    wl_l  = length(bands)
    spl_l = length(names)

    s = new_spectra(value = i_value(value, nbands = wl_l, nsample = spl_l),
                    bands = i_bands(bands),
                    names = i_names(names),
                    meta  = i_meta(meta, nsample = spl_l, match_nsample = extend_meta))

    ## Opt-in invariant check. Off by default (performance); enable with
    ## options(spectrolab.debug = TRUE).
    if(isTRUE(getOption("spectrolab.debug", FALSE))){
        validate_spectra(s, stop = TRUE)
    }

    s
}
